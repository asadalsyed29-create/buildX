BuildX game for Roblox Studio

1. Open Roblox Studio on your laptop. File > Open from File, and pick Game-Hub.rbxlx.
   Your parts, models, bots, lighting, GUIs, items and code are all in it.

2. Meshes and textures (5 meshes):
   Home > Import 3D (or File > Import 3D) and pick BuildXMeshes.glb.
   Leave "Merge Meshes" off, then press Import. The meshes come in with their textures.
   Then open View > Command Bar, paste this line and press Enter:
     require(game.ServerScriptService.BuildXRuntime.PlaceMeshes)()
   Each stand-in is swapped for its real mesh, in the same place, size and color, with its code.
   (If you skip the command, the meshes are still put in place when the game starts.)

Press Play to test. The BuildX code runs from ServerScriptService > BuildXRuntime.
Each part with code has BuildXSource (your code) and BuildXCode (ready to run) inside it.
If a command is not supported in Roblox yet, the Output window says so and that line is skipped.
To put the game online: File > Publish to Roblox.
